package com.microservices.applicationpropertiesconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationPropertiesConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
