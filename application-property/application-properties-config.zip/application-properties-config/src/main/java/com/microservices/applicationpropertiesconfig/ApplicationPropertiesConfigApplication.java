package com.microservices.applicationpropertiesconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationPropertiesConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationPropertiesConfigApplication.class, args);
	}

}
